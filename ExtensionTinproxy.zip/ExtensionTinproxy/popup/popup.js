const sendMessageForBackground = async (message, data) => {
  return await chrome.runtime.sendMessage({ greeting: message, data: data });
  // do something with response here, not outside the function
};

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  // check case
  switch (request.greeting) {
    case "getLocationsSuccess":
      if (request.data !== null) {
        const locations = request.data;
        locations.forEach((location) => {
          const option = document.createElement("option");
          option.textContent = location.name + " (" + location.code + ")";
          option.value = location.code;
          document.getElementById("location_select").append(option);
        });
      }
      break;
    case "processingGetProxyInfo":
      showProcessingConnect();
      break;
    case "failureGetProxyInfo":
      alertGetProxyInfo(request.data);
      break;
    case "successGetProxyInfo":
      storeProxyCache(request.data);
      countdowntime = request.data.next_request;
      showProxyInfo(request.data);
      break;
    case "successCheckVersion":
      checkversion(request);
      break;
    case "getClientIPSuccess":
      chrome.storage.sync.set({ whitelist_ip: request.data });
      break;

    default:
      break;
  }
});

sendMessageForBackground("getLocationsData");
sendMessageForBackground("getWhihtelistIp");

const checkversion = (res) => {
  const version = chrome.runtime.getManifest().version;
  if (compareVersions(res.data, version)) {
    window.open(
      "https://raw.githubusercontent.com/TinProxyVN/extension/main/ExtensionTinproxy.zip"
    );
  } else {
    return;
  }
};

const start = async () => {
  //check version tool
  sendMessageForBackground("checkVersion");

  const apiKey = localStorage.getItem("apiKey");
  const change_ip_type = localStorage.getItem("change_ip_type");
  const isConnect = localStorage.getItem("isConnect");
  const proxyType = localStorage.getItem("proxyType");
  const isAutoChangeIP = localStorage.getItem("isAutoChangeIP");
  const timeAutoChangeIP = localStorage.getItem("timeAutoChangeIP");

  if (isConnect == "1") {
    if (apiKey && change_ip_type && proxyType) {
      document.getElementById("api_key").value = apiKey;
      const listChangeIp = document.querySelectorAll("#radio-switch-change-ip");
      for (let i of listChangeIp) {
        if (i.value == change_ip_type) {
          i.checked = true;
        }
      }

      const listProxyType = document.querySelectorAll("#radio-switch-5");
      for (let i of listProxyType) {
        if (i.value == proxyType) {
          i.checked = true;
        }
      }
    }

    if (isAutoChangeIP && timeAutoChangeIP) {
      document.getElementById("is-auto-change").checked = isAutoChangeIP;
      document.getElementById("time-change-ip").value = timeAutoChangeIP;
    }

    const config = {
      apiKey: apiKey,
      proxyType: proxyType,
    };

    if (change_ip_type == "change") {
      sendMessageForBackground("changeIp", config);
    } else {
      sendMessageForBackground("getCurrentProxy", config);
    }
  } else {
    return;
  }

  //init
};
//click-btn-connect
document
  .getElementById("btn-connect")
  .addEventListener("click", async function () {
    // reset
    disableBtn("btn-connect");
    popupPageClear();
    //get key

    const apiKey = document.getElementById("api_key").value;
    if (apiKey === undefined || apiKey === "") {
      alertGetProxyInfo("Vui lòng nhập api key!");
      return;
    }

    localStorage.setItem("apiKey", apiKey);

    const listProxyType = document.querySelectorAll("#radio-switch-5");
    let proxyType = "";
    for (let i of listProxyType) {
      if (i.checked == true) {
        proxyType = i.value;
      }
    }

    const listLocation = document.querySelectorAll("#location_select");
    let location = "";
    for (let i of listLocation[0]) {
      if (i.selected == true) {
        location = i.value;
      }
    }

    const listChangeIp = document.querySelectorAll("#radio-switch-change-ip");
    let typeChangeIp = "keep";
    for (let i of listChangeIp) {
      if (i.checked == true && i.value == "change") {
        typeChangeIp = "change";
      }
    }

    const isAutoChangeIP = document.getElementById("is-auto-change").checked;
    const timeAutoChangeIP = document.getElementById("time-change-ip").value;
    const config = {
      apiKey: apiKey,
      isAutoChangeIP: isAutoChangeIP,
      timeAutoChangeIP: timeAutoChangeIP,
      proxyType: proxyType ? proxyType : "ipv4",
    };

    localStorage.setItem("isAutoChangeIP", isAutoChangeIP);
    localStorage.setItem("timeAutoChangeIP", timeAutoChangeIP);
    localStorage.setItem("change_ip_type", typeChangeIp);
    localStorage.setItem("proxyType", proxyType);
    localStorage.removeItem("isConnect");
    localStorage.setItem("isConnect", "1");

    if (isAutoChangeIP) {
      if (location) {
        config.location = location;
      }
      sendMessageForBackground("autoChangeIp", config);
    } else {
      if (typeChangeIp == "change") {
        if (location) {
          config.location = location;
        }
        sendMessageForBackground("changeIp", config);
      } else {
        sendMessageForBackground("getCurrentProxy", config);
      }
    }
  });

document
  .getElementById("btn-disconnect")
  .addEventListener("click", async function () {
    const proxyInfo = await getProxyFromCache();
    const config = {
      apiKey: proxyInfo.apiKey,
      isAutoChangeIP: false,
      timeAutoChangeIP: document.getElementById("time-change-ip").value,
    };
    localStorage.removeItem("isConnect");
    localStorage.setItem("isConnect", "0");
    storeConfCache(config);
    popupPageClear();
    sendMessageForBackground("cancelALL", config);
  });

function compareVersions(version1, version2) {
  // Tách các phần của phiên bản dựa trên dấu chấm
  const v1Parts = version1.split(".").map(Number);
  const v2Parts = version2.split(".").map(Number);

  // Đảm bảo cả hai phiên bản đều có số lượng phần giống nhau
  const length = Math.max(v1Parts.length, v2Parts.length);

  for (let i = 0; i < length; i++) {
    // Lấy giá trị của phần hiện tại, mặc định là 0 nếu không có phần
    const part1 = v1Parts[i] || 0;
    const part2 = v2Parts[i] || 0;

    if (part1 > part2) {
      return 1; // version1 lớn hơn version2
    } else if (part1 < part2) {
      return -1; // version1 nhỏ hơn version2
    }
  }

  return 0; // hai phiên bản bằng nhau
}

const popupPageClear = () => {
  disableBtn("btn-disconnect");
  enableBtn("btn-connect");
  document.getElementById("public_ipv4").innerText = "";
  document.getElementById("public_ipv6").innerText = "";
  document.getElementById("timeout").innerText = "";
  document.getElementById("next_time").innerText = "";
  document.getElementById("api_key_error").innerText = "";
  document.getElementById("ip-info").style.display = "none";
  document.getElementById("proxy-status").innerText = "Chưa kết nối";
  document.getElementById("proxy-status").classList.add("text-danger");
};

const storeConfCache = (config) => {
  chrome.storage.sync.set({ tx_conf: config });
};

const storeProxyCache = (proxy) => {
  chrome.storage.sync.set({ tx_proxy: proxy });
};

const showProcessingConnect = () => {
  document.getElementById("ip-info").style.display = null;
  document.getElementById("proxy-status").innerText = "Đang kết nối...";
  document.getElementById("proxy-status").classList.remove("text-success");
};

const showProxyInfo = (proxyInfo) => {
  document.getElementById("public_ipv4").innerText = proxyInfo.public_ip;
  document.getElementById("public_ipv6").innerText = proxyInfo.public_ip_ipv6;
  document.getElementById("timeout").innerText = fancyTimeFormat(
    proxyInfo.timeout
  );
  document.getElementById("next_time").innerText = "-";

  enableBtn("btn-disconnect");
  disableBtn("btn-connect");

  document.getElementById("proxy-status").innerText = "Đã kết nối";
  document.getElementById("ip-info").style.display = "block";
  document.getElementById("proxy-status").classList.remove("text-danger");
  document.getElementById("proxy-status").classList.add("text-success");

  countdowntime = proxyInfo.nextTime - Math.floor(Date.now() / 1000);
  countDownWorker();
};

const getProxyFromCache = async () => {
  let data = await getDataStorageChrome("tx_proxy");
  return data;
};

const getWhihtelistIpFromCacge = async () => {
  let data = await getDataStorageChrome("whitelist_ip");
  return data;
};

const getDataStorageChrome = (key) => {
  return new Promise((resolve, reject) => {
    try {
      chrome.storage.sync.get([key], function (items) {
        let data = items[key];
        if (data) {
          resolve(data);
        } else {
          resolve(null);
        }
      });
    } catch (error) {
      resolve(null);
    }
  });
};

const alertGetProxyInfo = (message) => {
  document.getElementById("api_key_error").innerText = message;
  document.getElementById("proxy-status").innerText = "Chưa kết nối";
};

function disableBtn(id) {
  document.getElementById(id).disabled = true;
}

function enableBtn(id) {
  document.getElementById(id).disabled = false;
}

start();

//----------------------------------------------------

const countDownWorker = () => {
  let nextTimeChange = setInterval(() => {
    document.getElementById("next_time").innerText = `${countdowntime} s`;

    countdowntime--;
    if (countdowntime < 0) {
      document.getElementById("next_time").innerText = `0 s`;
      clearInterval(nextTimeChange);
    }
  }, 1000);
};

//----------------------------------------------------
const fancyTimeFormat = (duration) => {
  // Hours, minutes and seconds
  var hrs = ~~(duration / 3600);
  var mins = ~~((duration % 3600) / 60);
  var secs = ~~duration % 60;

  // Output like "1:01" or "4:03:59" or "123:03:59"
  var ret = "";

  if (hrs > 0) {
    ret += "" + hrs + ":" + (mins < 10 ? "0" : "");
  }

  ret += "" + mins + ":" + (secs < 10 ? "0" : "");
  ret += "" + secs;
  return ret;
};
